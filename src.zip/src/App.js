import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LoginForm from './components/LoginForm';
import Sidebar from './components/Sidebar';
import MainContent from './components/MainContent';
import ProductList from './components/ProductList';
import AddProduct from './components/AddProduct';
import './custom-styles.css'; // Import your custom CSS file
import { Layout } from 'antd';

function App() {
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    useEffect(() => {
        // Replace with your actual authentication check
        setIsLoggedIn(!!localStorage.getItem('user'));
    }, []);

    return (
        <Router>
            <Layout style={{ minHeight: '100vh' }}>
                {isLoggedIn && <Sidebar />}
                <Layout>
                    <Routes>
                        <Route path="/login" element={<LoginForm onLoginSuccess={() => setIsLoggedIn(true)} />} />
                        <Route path="/" element={<Navigate replace to="/login" />} />
                        <Route path="/dashboard" element={<MainContent />}>
                            <Route path="products" element={<ProductList />} />
                            <Route path="add-product" element={<AddProduct mode="add" />} />
                            {/* Add other nested routes under dashboard if needed */}
                        </Route>
                        {/* Add other routes here if needed */}
                    </Routes>
                </Layout>
            </Layout>
        </Router>
    );
}

export default App;
