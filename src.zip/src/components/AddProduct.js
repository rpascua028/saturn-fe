import React, { useState, useEffect } from 'react';
import axios from 'axios';
import authService from '../services/authService';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheck } from '@fortawesome/free-solid-svg-icons';
import { Tag, Input, Button, Form} from 'antd';
import { PlusOutlined, SaveOutlined } from '@ant-design/icons'; // Import SaveOutlined icon


const AddProduct = ({ mode, productId }) => {
    const [productData, setProductData] = useState({
        name: '',
        category: [],
        sub_category: [],
        sub_heading: [],
        // ... other fields ...
    });

    const [categories, setCategories] = useState([]);
    const [subCategories, setSubCategories] = useState([]);
    const [subHeadings, setSubHeadings] = useState([]);

    useEffect(() => {
        axios
            .get('http://localhost:8000/api/admin/categories', {
                headers: {
                    Authorization: `Bearer ${authService.getToken()}`,
                },
            })
            .then((response) => {
                setCategories(response.data);
            })
            .catch((error) => {
                console.error('Error fetching categories', error);
            });

        axios
            .get('http://localhost:8000/api/admin/sub-categories', {
                headers: {
                    Authorization: `Bearer ${authService.getToken()}`,
                },
            })
            .then((response) => {
                setSubCategories(response.data);
            })
            .catch((error) => {
                console.error('Error fetching sub-categories', error);
            });

        axios
            .get('http://localhost:8000/api/admin/sub-headings', {
                headers: {
                    Authorization: `Bearer ${authService.getToken()}`,
                },
            })
            .then((response) => {
                setSubHeadings(response.data);
            })
            .catch((error) => {
                console.error('Error fetching sub-headings', error);
            });
    }, []);

    const toggleCategory = (categoryId) => {
        const updatedCategories = [...productData.category];

        if (updatedCategories.includes(categoryId)) {
            const index = updatedCategories.indexOf(categoryId);
            updatedCategories.splice(index, 1);
        } else {
            updatedCategories.push(categoryId);
        }

        setProductData({
            ...productData,
            category: updatedCategories,
        });
    };

    const toggleSubCategory = (subCategoryId) => {
        const updatedSubCategories = [...productData.sub_category];

        if (updatedSubCategories.includes(subCategoryId)) {
            const index = updatedSubCategories.indexOf(subCategoryId);
            updatedSubCategories.splice(index, 1);
        } else {
            updatedSubCategories.push(subCategoryId);
        }

        setProductData({
            ...productData,
            sub_category: updatedSubCategories,
        });
    };

    const toggleSubHeading = (subHeadingId) => {
        const updatedSubHeadings = [...productData.sub_heading];

        if (updatedSubHeadings.includes(subHeadingId)) {
            const index = updatedSubHeadings.indexOf(subHeadingId);
            updatedSubHeadings.splice(index, 1);
        } else {
            updatedSubHeadings.push(subHeadingId);
        }

        setProductData({
            ...productData,
            sub_heading: updatedSubHeadings,
        });
    };

    const renderCategoryChips = () => {
        return categories.map((category) => (
            <Tag
                key={category.id}
                color={
                    productData.category.includes(category.id) ? 'blue' : ''
                }
                className={`cursor-pointer mx-1 my-1 ${
                    productData.category.includes(category.id) ? 'ant-tag-has-color' : ''
                }`}
                onClick={() => toggleCategory(category.id)}
                style={{ fontSize: 'small' }} // Set the font size to 'large'
            >
                {category.name}{' '}
                {productData.category.includes(category.id) && (
                    <FontAwesomeIcon icon={faCheck} />
                )}
            </Tag>
        ));
    };

    const renderSubCategoryChips = () => {
        const visibleSubCategories = subCategories.filter((subCategory) => {
            return productData.category.includes(subCategory.category);
        });

        return visibleSubCategories.map((subCategory) => (
            <Tag
                key={subCategory.id}
                color={
                    productData.sub_category.includes(subCategory.id)
                        ? 'blue'
                        : 'default'
                }
                className="cursor-pointer mx-1 my-1"
                onClick={() => toggleSubCategory(subCategory.id)}
            >
                {subCategory.name}{' '}
                {productData.sub_category.includes(subCategory.id) && (
                    <FontAwesomeIcon icon={faCheck} />
                )}
            </Tag>
        ));
    };

    const renderSubHeadingChips = () => {
        const visibleSubHeadings = subHeadings.filter((subHeading) => {
            return productData.sub_category.includes(subHeading.sub_category);
        });

        return visibleSubHeadings.map((subHeading) => (
            <Tag
                key={subHeading.id}
                color={
                    productData.sub_heading.includes(subHeading.id)
                        ? 'blue'
                        : 'default'
                }
                className="cursor-pointer mx-1 my-1"
                onClick={() => toggleSubHeading(subHeading.id)}
            >
                {subHeading.name}{' '}
                {productData.sub_heading.includes(subHeading.id) && (
                    <FontAwesomeIcon icon={faCheck} />
                )}
            </Tag>
        ));
    };

    const handleSubmit = async (values) => {
        // Implement the handleSubmit function as before
    };

    return (
        <div className="container mx-auto p-4">
            <h1 className="text-2xl font-bold">
                {mode === 'add' ? 'Add New Product' : 'Edit Product'}
            </h1>
            <Form onFinish={handleSubmit}>
                <Form.Item label="Category">
                    <div className="flex flex-wrap">{renderCategoryChips()}</div>
                </Form.Item>
                <Form.Item label="Sub Category">
                    <div className="flex flex-wrap">
                        {renderSubCategoryChips()}
                    </div>
                </Form.Item>
                <Form.Item label="Sub Heading">
                    <div className="flex flex-wrap">
                        {renderSubHeadingChips()}
                    </div>
                </Form.Item>
                <Form.Item label="Product Name">
                    <Input
                        type="text"
                        name="name"
                        value={productData.name}
                        onChange={(e) =>
                            setProductData({
                                ...productData,
                                name: e.target.value,
                            })
                        }
                        disabled={mode === 'view'}
                    />
                </Form.Item>
                <Form.Item>
                    <Button
                        type="primary"
                        htmlType="submit"
                        icon={<SaveOutlined />} // Add SaveOutlined icon
                        disabled={mode === 'view'}
                    >
                        {mode === 'add' ? 'Save' : 'Save Changes'}
                    </Button>
                </Form.Item>
            </Form>

            {/* Category Modal */}
        </div>
    );
};

export default AddProduct;
