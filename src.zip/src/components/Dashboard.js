import React from 'react';
import Sidebar from './Sidebar'; // Adjust path if necessary
import MainContent from './MainContent'; // Adjust path if necessary



const Dashboard = () => {
    return (
        <div className="flex min-h-screen bg-gray-100">
            <Sidebar />
            <MainContent />
        </div>
    );
}

export default Dashboard;
