import React, { useState } from 'react';
import authService from '../services/authService';
import { useNavigate } from 'react-router-dom';
import { Input, Button, Form, Typography } from 'antd';
import { UserOutlined, LockOutlined } from '@ant-design/icons';

const { Title } = Typography;

const LoginForm = () => {
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const onFinish = (values) => {
        const { email, password } = values;

        if (!email || !password) {
            setError('Please enter all fields');
            return;
        }

        authService.login(email, password)
            .then(() => {
                navigate('/dashboard');
            })
            .catch(() => {
                setError('Invalid credentials or login error');
            });
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-100">
            <div className="bg-white p-6 rounded-lg shadow-lg">
                <Form
                    name="loginForm"
                    onFinish={onFinish}
                    initialValues={{
                        email: '',
                        password: '',
                    }}
                >
                    <Title level={2} className="text-center text-gray-900">
                        Login
                    </Title>
                    {error && <div className="text-red-500 text-sm text-center">{error}</div>}
                    <Form.Item
                        name="email"
                        rules={[
                            {
                                required: true,
                                message: 'Please enter your email!',
                            },
                        ]}
                    >
                        <Input
                            prefix={<UserOutlined className="site-form-item-icon" />}
                            type="email"
                            placeholder="Email"
                        />
                    </Form.Item>
                    <Form.Item
                        name="password"
                        rules={[
                            {
                                required: true,
                                message: 'Please enter your password!',
                            },
                        ]}
                    >
                        <Input
                            prefix={<LockOutlined className="site-form-item-icon" />}
                            type="password"
                            placeholder="Password"
                        />
                    </Form.Item>
                    <Form.Item>
                        <Button
                            type="primary"
                            htmlType="submit"
                            className="w-full font-bold"
                        >
                            Login
                        </Button>
                    </Form.Item>
                </Form>
            </div>
        </div>
    );
};

export default LoginForm;
