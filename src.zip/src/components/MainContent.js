import React, { useEffect } from 'react';
import { useNavigate, Outlet } from 'react-router-dom';
import authService from '../services/authService';
import { Layout, Breadcrumb } from 'antd';

const { Content } = Layout;

const MainContent = () => {
    const navigate = useNavigate();

    useEffect(() => {
        if (!authService.getToken()) {
            navigate('/login');
        }
    }, [navigate]);

    return (
        <Layout className="site-layout" style={{ marginLeft: 20 , marginLeft: 20 }}> {/* Adjust margin as per your sidebar width */}
            <Content style={{ margin: '24px 16px 0', overflow: 'initial' }}>
                <div className="site-layout-background" style={{ padding: 24, minHeight: 360, background: '#fff' }}>
                    <Outlet /> {/* This will render the nested route's component */}
                </div>
            </Content>
        </Layout>
    );
};

export default MainContent;
