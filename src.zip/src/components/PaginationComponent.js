import React from 'react';

const PaginationComponent = ({ currentPage, totalCount, itemsPerPage, onPageChange }) => {
    const totalPages = Math.ceil(totalCount / itemsPerPage);

    const renderPageNumbers = () => {
        let pages = [];
        for (let i = 1; i <= totalPages; i++) {
            pages.push(
                <button
                    key={i}
                    onClick={() => onPageChange(i)}
                    className={`py-2 px-4 ${i === currentPage ? 'bg-blue-500 text-white' : 'bg-white text-blue-500'} border border-blue-500 rounded`}
                >
                    {i}
                </button>
            );
        }
        return <div className="flex space-x-2 mt-4">{pages}</div>;
    };

    return totalPages > 1 ? renderPageNumbers() : null;
};

export default PaginationComponent;
