import React, { useEffect, useState } from 'react';
import axios from 'axios';
import authService from '../services/authService';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrash, faArrowLeft,  } from '@fortawesome/free-solid-svg-icons';

// Import Ant Design components and styles
import { Table, Input, Button, Space, Modal } from 'antd';
import { PlusOutlined, MoreOutlined,DeleteOutlined} from '@ant-design/icons'; 
const { Search } = Input;

const ProductList = () => {
    const [products, setProducts] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalCount, setTotalCount] = useState(0);
    const [popupVisible, setPopupVisible] = useState(false);
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [sortColumn, setSortColumn] = useState('id');
    const [sortDirection, setSortDirection] = useState('asc');
    const [isDeleteConfirmationOpen, setIsDeleteConfirmationOpen] = useState(false);

    const navigate = useNavigate();
    const ITEMS_PER_PAGE = 10;

    const handleAddProduct = () => {
        navigate('/dashboard/add-product'); // Adjusted navigation path
    };

    const fetchProducts = async (page = 1) => {
        const url = `http://localhost:8000/api/admin/products?limit=${ITEMS_PER_PAGE}&offset=${(page - 1) * ITEMS_PER_PAGE}&search=${searchQuery}&ordering=${sortDirection === 'asc' ? '' : '-'}${sortColumn}`;
        try {
            const response = await axios.get(url, {
                headers: {
                    'Authorization': `Bearer ${authService.getToken()}`,
                }
            });
            setProducts([]); // Clear existing products
            setProducts(response.data.results);
            setTotalCount(response.data.count);
            setCurrentPage(page);
        } catch (error) {
            console.error('Error fetching products', error);
        }
    };

    useEffect(() => {
        fetchProducts();
    }, [searchQuery, sortColumn, sortDirection]);

    const handleViewMoreClick = (product) => {
        setSelectedProduct(product);
        setPopupVisible(true);
    };

    const handleSearchInputChange = (e) => {
        setSearchQuery(e.target.value);
    };

    const handleDeleteProduct = async (productId) => {
        try {
            await axios.delete(`http://localhost:8000/api/admin/products/${productId}`, {
                headers: {
                    'Authorization': `Bearer ${authService.getToken()}`,
                },
            });

            fetchProducts(currentPage);
        } catch (error) {
            if (error.response && error.response.status === 404) {
                console.error('Product not found.');
            } else {
                console.error('Error deleting product', error);
            }
        }
        setIsDeleteConfirmationOpen(false);
    };

    const ConfirmationDialog = ({ isOpen, onCancel, onConfirm }) => {
        if (!isOpen) return null;

        return (
            <Modal
                title="Confirm Deletion"
                visible={isOpen}
                onCancel={onCancel}
                footer={[
                    <Button key="cancel" onClick={onCancel}>
                        Cancel
                    </Button>,
                    <Button key="confirm" type="primary" danger onClick={onConfirm}>
                        Confirm
                    </Button>,
                ]}
            >
                <p>Are you sure you want to delete this product?</p>
            </Modal>
        );
    };

    return (
        <div className="container mx-auto p-4">
            <div className="flex justify-between items-center mb-4">
                <h1 className="text-2xl font-bold">Product List</h1>
                <Button
                    type="primary"
                    icon={<PlusOutlined />}
                    style={{ marginRight: '8px' }} // You can add extra custom styles if needed
                    onClick={handleAddProduct}
                    >
                    Add Product
                    </Button>
            </div>
            <div className="mb-4">
                <Search
                    placeholder="Search products"
                    value={searchQuery}
                    onChange={handleSearchInputChange}
                    style={{ width: 200 }}
                />
            </div>
            <Table
                dataSource={products}
                columns={[
                    {
                        title: 'ID',
                        dataIndex: 'id',
                        key: 'id',
                        sorter: true,
                    },
                    {
                        title: 'Name',
                        dataIndex: 'name',
                        key: 'name',
                        sorter: true,
                    },
                    {
                        title: 'Top Category',
                        dataIndex: 'category',
                        key: 'category',
                        render: (text, record) => (
                            <span>
                                {text.length > 0 ? (
                                    <span>
                                        {text[0].name}
                                        {text.length > 1 && (
                                            <Button
                                            type="primary"
                                            shape='circle'
                                            icon={<MoreOutlined />} // Use Ant Design icon directly here
                                            onClick={() => handleViewMoreClick(record)}
                                          >
                                            </Button>
                                        )}
                                    </span>
                                ) : ''}
                            </span>
                        ),
                    },
                    {
                        title: 'Brand',
                        dataIndex: ['brand', 'name'],
                        key: 'brand.name',
                        sorter: true,
                    },
                    {
                        title: 'Actions',
                        key: 'actions',
                        render: (text, record) => (
                            <Space size="middle">
                                <Button
                                    type="danger"
                                    onClick={() => {
                                        setSelectedProduct(record);
                                        setIsDeleteConfirmationOpen(true);
                                    }}
                                >
                                    <DeleteOutlined />
                                </Button>
                            </Space>
                        ),
                    },
                ]}
                pagination={{
                    total: totalCount,
                    pageSize: ITEMS_PER_PAGE,
                    current: currentPage,
                    onChange: (page) => fetchProducts(page),
                }}
                onChange={(pagination, filters, sorter) => {
                    if (sorter.order) {
                        setSortColumn(sorter.field);
                        setSortDirection(sorter.order === 'ascend' ? 'asc' : 'desc');
                    }
                }}
            />
            {popupVisible && selectedProduct && (
                <div className="fixed inset-0 flex items-center justify-center z-50">
                    <div className="absolute inset-0 bg-black opacity-50" onClick={() => setPopupVisible(false)}></div>
                    <div className="bg-white p-4 rounded shadow-lg z-10">
                        <h2 className="text-lg font-semibold mb-2">All Categories</h2>
                        <ul>
                            {selectedProduct.category.map(category => (
                                <li key={category.id}>{category.name}</li>
                            ))}
                        </ul>
                        <div className="mt-4">
                            <Button
                                type="primary"
                                icon={<FontAwesomeIcon icon={faArrowLeft} />}
                                onClick={() => setPopupVisible(false)}
                            >
                                Close
                            </Button>
                        </div>
                    </div>
                </div>
            )}
            <ConfirmationDialog
                isOpen={isDeleteConfirmationOpen}
                onCancel={() => setIsDeleteConfirmationOpen(false)}
                onConfirm={() => handleDeleteProduct(selectedProduct.id)}
            />
        </div>
    );
}

export default ProductList;
