import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout, Menu } from 'antd';
import {
  PieChartOutlined,
  DesktopOutlined,
  UserOutlined,
  TeamOutlined,
  FileOutlined,
  LogoutOutlined, // Added for logout icon
} from '@ant-design/icons';

const { Sider } = Layout;

const Sidebar = () => {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('user'); // Adjust as per your token storage
    navigate('/login');
  };

  const items = [
    {
      key: '1',
      icon: <PieChartOutlined />,
      label: 'My Account',
      onClick: () => navigate('/my-account'), // Update with correct path
    },
    {
      key: '2',
      icon: <DesktopOutlined />,
      label: 'Products',
      onClick: () => navigate('/dashboard/products'),
    },
    {
      key: '3',
      icon: <LogoutOutlined />,
      label: 'Logout',
      onClick: handleLogout,
    },
    // Add more items here as needed
  ];

  return (
    <Sider collapsible collapsed={collapsed} onCollapse={setCollapsed}>
      <div className="demo-logo-vertical" />
      <Menu theme="dark" defaultSelectedKeys={['1']} mode="inline" items={items} />
    </Sider>
  );
};

export default Sidebar;
