// authService.js
import axios from 'axios';

const API_URL = 'http://localhost:8000/api/admin/login';

const login = (email, password) => {
    return axios.post(API_URL, { email, password })
        .then(response => {
            if (response.data.access) {
                localStorage.setItem('userToken', response.data.access);
            }
            return response.data;
        });
};

const logout = () => {
    localStorage.removeItem('userToken');
};

const getToken = () => {
    return localStorage.getItem('userToken'); // Corrected key to 'userToken'
};

export default {
    login,
    logout,
    getToken
};
